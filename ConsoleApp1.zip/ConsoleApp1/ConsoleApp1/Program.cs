﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            //Man is a type
            //man is an instance of Man type
            //new Man is invoking constructor method of Man type
            Man man = new Man();
            man.Email = "samir@code.az";
            Console.WriteLine(man.Email);

            Console.WriteLine(man.Phone);
            man.Phone = "+994 70 954 7474";

            #region Try-catch-finally
            //try
            //{
            //    MailAddress mail = new MailAddress("gulu@gulu");
            //    Console.WriteLine("Try worked successfully");
            //}
            //catch
            //{
            //    Console.WriteLine("Catch block caught error");
            //}
            //finally
            //{
            //    Console.WriteLine("Finally just worked");
            //}
            #endregion

            #region Try-Catch
            //try
            //{
            //    checked
            //    {
            //        byte a = 255;
            //        a += 10;
            //    }
            //    //MailAddress mail = new MailAddress(email);
            //}
            //catch (ArgumentNullException)
            //{
            //    Console.ForegroundColor = ConsoleColor.Red;
            //    Console.WriteLine("Dear user, Null value was assigned to email.");
            //    Console.ForegroundColor = ConsoleColor.White;
            //}
            //catch (ArgumentException)
            //{
            //    Console.WriteLine("Dear user, Empty string was assigned to email.");
            //}
            //catch (FormatException)
            //{
            //    Console.WriteLine("Deer user, email is not valid.");
            //}
            //catch (OverflowException)
            //{
            //    Console.WriteLine("Dear user, number provided was too much for byte to hold.");
            //}
            //catch (Exception)
            //{
            //    Console.WriteLine("Unknown error occurred");
            //}

            #endregion
        }
    }

    abstract class Person
    {
        public int Id;
        public string Firstname;
        public string Lastname;

        private string _phone;
        public string Phone
        {
            get { return _phone; }
            set
            {
                Regex regex = new Regex(@"(\+994) (50|51|55|70|77)-? *[2-9]{1}\d{2}-? *-?\d{4}");
                if(regex.IsMatch(value))
                {
                    _phone = value;
                }
                else
                {
                    throw new ArgumentException("Phone number is not in a correct format");
                }
            }
        }


        #region Encapsulating email field
        //private string _email;
        //public void SetEmail(string email)
        //{
        //    //to do
        //    if(email.IndexOf("@") != -1)
        //    {
        //        _email = email;
        //        return;
        //    }

        //    throw new ArgumentException("Email address is not valid");
        //}
        //public string GetEmail()
        //{
        //    return _email;
        //}
        #endregion

        #region Encapsulating email field with properties

        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                try
                {
                    MailAddress mailAddress = new MailAddress(value);
                    _email = value;
                }
                catch (Exception ex)
                {
                    throw new ArgumentException("Email is not valid");
                }

            }
        }


        #endregion


    }

    class Man : Person
    {

    }
}
